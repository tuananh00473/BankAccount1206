package com.qsoft;

/**
 * Created with IntelliJ IDEA.
 * User: Admin
 * Date: 6/12/13
 * Time: 9:20 AM
 * To change this template use File | Settings | File Templates.
 */
public class BankAccountDAO {

    public BankAccountDTO openAccount(BankAccountDTO bankAccountDTO) {
        return null;
    }

    public BankAccountDTO save(BankAccountDTO bankAccountDTO) {
        return null;
    }

    public BankAccountDTO getAccount(String accountNumber) {
        return null;
    }
}
