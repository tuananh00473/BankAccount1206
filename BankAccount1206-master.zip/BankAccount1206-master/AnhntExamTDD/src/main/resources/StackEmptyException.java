/**
 * Created with IntelliJ IDEA.
 * User: Admin
 * Date: 6/18/13
 * Time: 11:57 AM
 * To change this template use File | Settings | File Templates.
 */
public class StackEmptyException extends RuntimeException{
    public StackEmptyException(String message) {
        super(message);
    }
}
