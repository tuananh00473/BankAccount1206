package qsoft.shoppingcart;

/**
 * Created with IntelliJ IDEA.
 * User: Admin
 * Date: 5/23/13
 * Time: 11:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class Item {
    String nameProduce;
    int costProduce;

    public Item(String nameProduce, int costProduce) {
        this.nameProduce = nameProduce;
        this.costProduce = costProduce;
    }
}
